# Sistema de Cotización Automática - Guía de Uso

## 📌 Descripción
Sistema que permite configurar una cotización del día para convertir automáticamente precios desde una moneda extranjera (USD, EUR, etc.) a pesos argentinos (ARS).

## 🎯 Funcionalidad Principal

### 1. Configurar Cotización del Día
1. En el **sidebar** del panel admin, verás un widget de "Cotización"
2. Haz clic en el ícono de editar (lápiz) o en el botón "Cambiar" dentro del formulario de variantes
3. Se abrirá el modal de configuración donde podrás:
   - Seleccionar la moneda base (USD, EUR, BRL, etc.)
   - Ingresar el valor de cotización (cuántos ARS = 1 unidad de moneda extranjera)
   - Ver un ejemplo de cálculo
4. Haz clic en "Guardar Cotización"

**Ejemplo:**
- Si 1 USD = 1000 ARS, ingresa 1000 en el campo de cotización

### 2. Agregar/Editar Variantes con Cotización

Cuando creas o editas una variante:

1. **Verás la cotización actual** en la parte superior del formulario
2. **Ingresa el precio base** en la moneda extranjera (ej: USD 100)
3. **El precio final en ARS se calcula automáticamente** (ej: $100,000 ARS)

El precio final (calculado) es el que se guarda en la base de datos.

### 3. Editar Variantes Existentes

Cuando editas una variante existente:
- El sistema calcula automáticamente el precio base dividiendo el precio guardado por la cotización actual
- Puedes modificar el precio base y se recalculará el precio final

## 🔧 Archivos Creados/Modificados

### Archivos Nuevos:
1. **`admin/js/cotizacion.js`** - Gestor de cotización
2. **`admin/components/cotizacion-modal.html`** - Modal de configuración
3. **`admin/COTIZACION_GUIA.md`** - Esta guía

### Archivos Modificados:
1. **`admin/components/FormVariante.html`** - Campos de precio actualizados
2. **`admin/js/FormVariante.js`** - Lógica de cálculo automático
3. **`admin/components/sidebar.html`** - Widget de cotización
4. **`admin/variants.html`** - Scripts y componentes cargados

## 💾 Almacenamiento

La cotización se guarda en **localStorage** del navegador con la clave `origami_cotizacion_dia`.

Formato:
```json
{
  "valor": 1000.50,
  "fecha": "2025-11-24T...",
  "moneda": "USD"
}
```

## 📊 Ejemplo de Uso Completo

**Escenario:** Quieres vender un iPhone a USD 800

1. **Configurar cotización:**
   - Moneda: USD
   - Cotización: 1050 (1 USD = 1050 ARS)

2. **Crear variante:**
   - Precio Base (USD): 800
   - Precio Final (ARS): $840,000 (calculado automáticamente)

3. **Si cambia la cotización:**
   - Nueva cotización: 1100 ARS
   - Al editar la variante existente, verás:
     - Precio Base: ~763.64 USD (calculado desde los $840,000 guardados)
   - Puedes ajustar el precio base si es necesario

## ⚠️ Notas Importantes

- La cotización NO actualiza automáticamente los precios ya guardados
- Debes actualizar manualmente las variantes si la cotización cambia significativamente
- El sistema está diseñado para facilitar la carga de nuevos productos
- El precio guardado en la base de datos es siempre el precio final en ARS

## 🔄 Flujo de Trabajo Recomendado

1. **Al inicio del día:** Configura la cotización actual
2. **Al agregar productos:** Ingresa precios en la moneda extranjera
3. **Si cambia la cotización:** Actualiza la configuración
4. **Para productos existentes:** Edita manualmente si es necesario

## 🛠️ Soporte Técnico

Si encuentras problemas:
1. Verifica que la cotización esté configurada (sidebar debe mostrar el valor)
2. Recarga la página con Ctrl+F5
3. Abre la consola del navegador (F12) para ver errores
4. Verifica que todos los scripts se hayan cargado correctamente
